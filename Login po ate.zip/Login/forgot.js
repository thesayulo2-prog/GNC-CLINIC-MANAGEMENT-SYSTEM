// =============================
// INPUTS
// =============================
const role = document.getElementById("role");
const email = document.getElementById("email");
const newPassword = document.getElementById("newPassword");
const confirmPassword = document.getElementById("confirmPassword");
const resetBtn = document.getElementById("resetBtn");

const strengthText = document.getElementById("strengthText");

newPassword.addEventListener("input", () => {
  const val = newPassword.value;

  if (val.length < 8) {
    strengthText.textContent = "Weak (min 8 characters)";
    strengthText.style.color = "red";
  } 
  else if (
    val.match(/[A-Z]/) &&
    val.match(/[0-9]/)
  ) {
    strengthText.textContent = "Strong password";
    strengthText.style.color = "green";
  } 
  else {
    strengthText.textContent = "Medium password";
    strengthText.style.color = "orange";
  }
});

// =============================
// ERRORS
// =============================
const roleError = document.getElementById("roleError");
const emailError = document.getElementById("emailError");
const passwordError = document.getElementById("passwordError");
const confirmError = document.getElementById("confirmError");

// =============================
// CUSTOM DROPDOWN
// =============================
const selectBox = document.getElementById("selected");
const optionsContainer = document.querySelector(".options-container");
const options = document.querySelectorAll(".option");

// disable typing
selectBox.addEventListener("keydown", (e) => e.preventDefault());

// toggle dropdown
selectBox.addEventListener("click", () => {
  optionsContainer.style.display =
    optionsContainer.style.display === "block" ? "none" : "block";
});

// select option
options.forEach(option => {
  option.addEventListener("click", () => {
    selectBox.textContent = option.textContent;
    role.value = option.getAttribute("data-value");

    role.dispatchEvent(new Event("change"));
    optionsContainer.style.display = "none";
  });
});

// close when clicking outside
document.addEventListener("click", (e) => {
  if (!document.getElementById("roleSelect").contains(e.target)) {
    optionsContainer.style.display = "none";
  }
});

// =============================
// ENABLE BUTTON
// =============================
function checkValidity() {
  if (
    role.value !== "" &&
    email.value.trim() !== "" &&
    newPassword.value.length >= 8 &&
    newPassword.value === confirmPassword.value
  ) {
    resetBtn.disabled = false;
  } else {
    resetBtn.disabled = true;
  }
}

role.addEventListener("change", checkValidity);
email.addEventListener("input", checkValidity);
newPassword.addEventListener("input", checkValidity);
confirmPassword.addEventListener("input", checkValidity);

// =============================
// SUBMIT
// =============================
document.getElementById("forgotForm").addEventListener("submit", function(e) {
  e.preventDefault();

  // reset errors
  roleError.textContent = "";
  emailError.textContent = "";
  passwordError.textContent = "";
  confirmError.textContent = "";

  let users = JSON.parse(localStorage.getItem("users")) || [];

  // ROLE CHECK
  if (role.value === "") {
    roleError.textContent = "Please select a role";
    return;
  }

  // FIND USER
  const index = users.findIndex(user =>
    user.email === email.value.trim().toLowerCase() &&
    user.role === role.value
  );

  if (index === -1) {
    emailError.textContent = "Account not found";
    return;
  }

  // PASSWORD VALIDATION
  if (newPassword.value.length < 8) {
    passwordError.textContent = "Password must be at least 6 characters";
    return;
  }

  if (newPassword.value !== confirmPassword.value) {
    confirmError.textContent = "Passwords do not match";
    return;
  }

  // UPDATE PASSWORD
  users[index].password = newPassword.value;
  localStorage.setItem("users", JSON.stringify(users));

  // REDIRECT
  window.location.href = "login.html";
});