// =============================
// GET ELEMENTS
// =============================
const role = document.getElementById("role");
const email = document.getElementById("email");
const password = document.getElementById("password");
const loginBtn = document.getElementById("loginBtn");
const loginError = document.getElementById("loginError");

// =============================
// CUSTOM DROPDOWN (FIXED)
// =============================
const selectBox = document.getElementById("selected");
const optionsContainer = document.querySelector(".options-container");
const options = document.querySelectorAll(".option");

document.getElementById("selected").addEventListener("keydown", (e) => {
  e.preventDefault();
});

// toggle dropdown
selectBox.addEventListener("click", () => {
  optionsContainer.style.display =
    optionsContainer.style.display === "block" ? "none" : "block";
});

// select option
options.forEach(option => {
  option.addEventListener("click", () => {
    selectBox.textContent = option.textContent;
    role.value = option.getAttribute("data-value");

    // 🔥 trigger validation
    role.dispatchEvent(new Event("change"));

    optionsContainer.style.display = "none";
  });
});

// close dropdown when clicking outside
document.addEventListener("click", (e) => {
  if (!document.getElementById("roleSelect").contains(e.target)) {
    optionsContainer.style.display = "none";
  }
});

// =============================
// VALIDATION (ENABLE BUTTON)
// =============================
function checkLoginValidity() {
  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

  if (
    role.value !== "" &&
    email.value.match(emailPattern) &&
    password.value.length >= 8
  ) {
    loginBtn.disabled = false;
  } else {
    loginBtn.disabled = true;
  }
}

role.addEventListener("change", checkLoginValidity);
email.addEventListener("input", checkLoginValidity);
password.addEventListener("input", checkLoginValidity);

// =============================
// CLEAR ERROR
// =============================
email.addEventListener("input", () => loginError.textContent = "");
password.addEventListener("input", () => loginError.textContent = "");

// =============================
// LOGIN SUBMIT
// =============================
document.getElementById("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const users = JSON.parse(localStorage.getItem("users")) || [];

  const foundUser = users.find(user =>
    user.role === role.value &&
    user.email === email.value.trim().toLowerCase() &&
    user.password === password.value
  );

  if (foundUser) {
    localStorage.setItem("currentUser", JSON.stringify(foundUser));

    if (foundUser.role === "ADMIN") {
      window.location.href = "admindashboard.html";
    } else {
      window.location.href = "userdashboard.html";
    }

  } else {
    loginError.textContent = "Invalid email or password";
  }
});