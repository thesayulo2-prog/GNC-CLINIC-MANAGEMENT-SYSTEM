// =============================
// GET ELEMENTS
// =============================
const role = document.getElementById("role");
const name = document.getElementById("name");
const email = document.getElementById("email");
const password = document.getElementById("password");
const confirmPassword = document.getElementById("confirmPassword");
const registerBtn = document.getElementById("registerBtn");

const strengthText = document.getElementById("strengthText");

password.addEventListener("input", () => {
  const val = password.value;

  if (val.length < 8) {
    strengthText.textContent = "Weak (min 8 characters)";
    strengthText.style.color = "red";
  } 
  else if (
    val.match(/[A-Z]/) &&
    val.match(/[0-9]/)
  ) {
    strengthText.textContent = "Strong password";
    strengthText.style.color = "green";
  } 
  else {
    strengthText.textContent = "Medium password";
    strengthText.style.color = "orange";
  }
});

// =============================
// CUSTOM DROPDOWN
// =============================
const selectBox = document.getElementById("selected");
const optionsContainer = document.querySelector(".options-container");
const options = document.querySelectorAll(".option");

document.getElementById("selected").addEventListener("keydown", (e) => {
  e.preventDefault();
});

// toggle
selectBox.addEventListener("click", () => {
  optionsContainer.style.display =
    optionsContainer.style.display === "block" ? "none" : "block";
});

// select option
options.forEach(option => {
  option.addEventListener("click", () => {
    selectBox.textContent = option.textContent;
    role.value = option.getAttribute("data-value");

    // trigger validation
    role.dispatchEvent(new Event("change"));

    optionsContainer.style.display = "none";
  });
});

// close outside
document.addEventListener("click", (e) => {
  if (!document.getElementById("roleSelect").contains(e.target)) {
    optionsContainer.style.display = "none";
  }
});

// =============================
// VALIDATION (ENABLE BUTTON)
// =============================
function checkFormValidity() {
  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

  if (
    role.value !== "" &&
    name.value.trim() !== "" &&
    email.value.match(emailPattern) &&
    password.value.length >= 8 &&
    password.value === confirmPassword.value
  ) {
    registerBtn.disabled = false;
  } else {
    registerBtn.disabled = true;
  }
}

role.addEventListener("change", checkFormValidity);
name.addEventListener("input", checkFormValidity);
email.addEventListener("input", checkFormValidity);
password.addEventListener("input", checkFormValidity);
confirmPassword.addEventListener("input", checkFormValidity);

// =============================
// SUBMIT REGISTER
// =============================
document.getElementById("registerForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const user = {
    role: role.value,
    name: name.value,
    email: email.value.trim().toLowerCase(),
    password: password.value
  };

  let users = JSON.parse(localStorage.getItem("users")) || [];

  users.push(user);

  localStorage.setItem("users", JSON.stringify(users));

  window.location.href = "login.html";
});