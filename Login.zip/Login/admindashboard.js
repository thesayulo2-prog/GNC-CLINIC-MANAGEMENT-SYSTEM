const user = JSON.parse(localStorage.getItem("currentUser"));

if (!user || user.role !== "ADMIN") {
  window.location.href = "login.html";
}

document.getElementById("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem("currentUser");
  window.location.href = "login.html";
});