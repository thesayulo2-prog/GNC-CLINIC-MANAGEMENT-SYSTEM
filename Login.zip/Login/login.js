// =============================
// GET ELEMENTS (TOP)
// =============================
const role = document.getElementById("role");
const email = document.getElementById("email");
const password = document.getElementById("password");
const loginBtn = document.getElementById("loginBtn");
const loginError = document.getElementById("loginError");


// =============================
// CLEAR ERROR WHEN USER TYPES
// 👉 PUT YOUR CODE HERE
// =============================
email.addEventListener("input", () => {
  loginError.textContent = "";
});

password.addEventListener("input", () => {
  loginError.textContent = "";
});

role.addEventListener("change", () => {
  loginError.textContent = "";
});


// =============================
// ENABLE BUTTON WHEN VALID
// =============================
function checkLoginValidity() {
  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

  if (
    role.value !== "" &&
    email.value.match(emailPattern) &&
    password.value.trim() !== ""
  ) {
    loginBtn.disabled = false;
  } else {
    loginBtn.disabled = true;
  }
}

role.addEventListener("change", checkLoginValidity);
email.addEventListener("input", checkLoginValidity);
password.addEventListener("input", checkLoginValidity);


// =============================
// LOGIN SUBMIT
// =============================
document.getElementById("loginForm").addEventListener("submit", function(e) {

  e.preventDefault();

const users = JSON.parse(localStorage.getItem("users")) || [];

const foundUser = users.find(user =>
  user.role === role.value &&
  user.email === email.value.trim().toLowerCase() &&
  user.password === password.value
);

if (foundUser) {
  localStorage.setItem("currentUser", JSON.stringify(foundUser));

if (foundUser.role === "ADMIN") {
  window.location.href = "admindashboard.html"; // ✅ correct
} else {
  window.location.href = "userdashboard.html"; // already fixed
}

} else {
  loginError.textContent = "Invalid email or password";
}

});