// =============================
// GET ELEMENTS (TOP)
// =============================
const registerBtn = document.getElementById("registerBtn");

const role = document.getElementById("role");
const name = document.getElementById("name");
const email = document.getElementById("email");
const password = document.getElementById("password");
const confirmPassword = document.getElementById("confirmPassword");


// =============================
// LIVE VALIDATION (ENABLE BUTTON)
// =============================
function checkFormValidity() {
  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

  if (
    role.value !== "" &&
    name.value.trim() !== "" &&
    email.value.match(emailPattern) &&
    password.value.length >= 6 &&
    password.value === confirmPassword.value
  ) {
    registerBtn.disabled = false;
  } else {
    registerBtn.disabled = true;
  }
}

// LISTENERS
role.addEventListener("change", checkFormValidity);
name.addEventListener("input", checkFormValidity);
email.addEventListener("input", checkFormValidity);
password.addEventListener("input", checkFormValidity);
confirmPassword.addEventListener("input", checkFormValidity);


// =============================
// ✅ PUT YOUR CODE HERE (BOTTOM)
// =============================
document.getElementById("registerForm").addEventListener("submit", function(e) {

  e.preventDefault();

  let isValid = true;
  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

  if (role.value === "") isValid = false;
  if (name.value.trim() === "") isValid = false;
  if (!email.value.match(emailPattern)) isValid = false;
  if (password.value.length < 6) isValid = false;
  if (password.value !== confirmPassword.value) isValid = false;

  if (isValid) {

  const user = {
    role: role.value,
    name: name.value,
    email: email.value.trim().toLowerCase(),
    password: password.value
  };

  let users = JSON.parse(localStorage.getItem("users")) || [];

users.push(user);

localStorage.setItem("users", JSON.stringify(users));

  window.location.href = "login.html";
}

});