<div id="sidebar">
    <div class="sidebar-logo">
        <img src="gnc logo.png" alt="GNCI Logo">
    </div>
    <ul class="nav-links">
        <li><a href="dashboard.php"><img src="dash.png" class="nav-icon"> Dashboard</a></li>
        <li><a href="inventory.php"><img src="inventory.png" class="nav-icon"> Inventory</a></li>
        <li><a href="index.php"><img src="transaction.png" class="nav-icon"> Transaction Record</a></li>
       <li><a href="transaction_history.php"><img src="history.png" class="nav-icon"> Transaction History</a></li>
        <li><a href="user.php"><img src="user management.png" class="nav-icon"> User Management</a></li>
    </ul>
</div>