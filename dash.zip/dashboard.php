<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard | GNCI</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include('sidebar.php'); ?>

<div id="content">

    <!-- Top Navbar -->
    <header class="top-navbar">
        <div style="width:50px;"></div>

        <div class="header-title">
            GNCI CLINIC MANAGEMENT SYSTEM
        </div>

        <div class="header-right">
            <i class="fa-regular fa-envelope"></i>
            <i class="fa-regular fa-bell"></i>

            <!-- PROFILE DROPDOWN START -->
            <div class="profile-container">
                <div class="profile-circle" onclick="toggleMenu()">
                    <img src="profile.png">
                </div>

                <div id="profileMenu" class="profile-menu">
                    <a href="profile.php">Profile</a>
                    <a href="settings.php">Settings</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
            <!-- PROFILE DROPDOWN END -->

        </div>
    </header>

    <main class="main-container">

        <h2 class="dashboard-title">ADMIN DASHBOARD</h2>

        <!-- SUMMARY CARDS -->
        <div class="dashboard-cards">
            <div class="dash-card">
                <span>TODAY’S ADMISSION/STUDENTS</span>
                <h3>1</h3>
            </div>
            <div class="dash-card">
                <span>TODAY’S TRANSACTION</span>
                <h3>3</h3>
            </div>
            <div class="dash-card">
                <span>TOTAL MEDICINE SUPPLIES</span>
                <h3>253</h3>
            </div>
            <div class="dash-card">
                <span>OTHER NECESSITIES</span>
                <h3>53</h3>
            </div>
        </div>

        <!-- LOWER DASHBOARD -->
        <div class="dashboard-grid">

            <!-- RECENT TRANSACTIONS -->
            <div class="dashboard-box recent-transactions">
                <div class="box-header">
                    <span>RECENT TRANSACTIONS</span>
                    <strong class="add-btn">+</strong>
                </div>

                <ul class="recent-list">
                    <li>
                        Thesa Shane G. Yulo
                        <span class="tag blue">Necessities</span>
                    </li>
                    <li>
                        Taylor A. Swift
                        <span class="tag red">Admitted</span>
                    </li>
                    <li>
                        Limuel B. Escultura
                        <span class="tag green">Medicine</span>
                    </li>
                </ul>
            </div>

            <!-- CHARTS -->
            <div class="charts-grid">

                <div class="dashboard-box">
                    <span class="box-title">MOST USED MEDICINE</span>
                    <canvas id="medicineChart"></canvas>
                </div>

                <div class="dashboard-box">
                    <span class="box-title">MOST USED NECESSITIES / SUPPLIES</span>
                    <canvas id="necessitiesChart"></canvas>
                </div>

                <div class="dashboard-box chart-wide">
                    <span class="box-title">OVERALL TRANSACTIONS</span>
                    <canvas id="overallChart"></canvas>
                </div>

            </div>
        </div>

    </main>
</div>

<!-- CHART JS -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
new Chart(document.getElementById('medicineChart'), {
    type: 'pie',
    data: {
        labels: ['Neozep', 'Biogesic', 'Loperamide'],
        datasets: [{
            data: [20, 10, 70],
            backgroundColor: ['#0088FF', '#EF4444', '#22C55E']
        }]
    },
    options: {
        plugins: {
            legend: {
                position: 'right'
            }
        }
    }
});

new Chart(document.getElementById('necessitiesChart'), {
    type: 'pie',
    data: {
        labels: ['Wheelchair', 'Betadine', 'Bandages', 'Alcohol', 'Face Mask'],
        datasets: [{
            data: [28, 20, 10, 15, 45],
            backgroundColor: ['#D2970B','#0088FF','#EF4444','#E9F45B','#22C55E']
        }]
    },
    options: {
        plugins: {
            legend: {
                position: 'right'
            }
        }
    }
});

new Chart(document.getElementById('overallChart'), {
    type: 'bar',
    data: {
        labels: ['Admission', 'Medicine', 'Necessities'],
        datasets: [{
            data: [10, 70, 20],
            backgroundColor: '#22C55E'
        }]
    },
    options: {
        plugins: {
            legend: { display: false }
        }
    }
});

/* PROFILE DROPDOWN */
function toggleMenu() {
    document.getElementById("profileMenu").classList.toggle("show");
}

window.onclick = function(e) {
    if (!e.target.closest('.profile-container')) {
        document.getElementById("profileMenu").classList.remove("show");
    }
}
</script>

</body>
</html>