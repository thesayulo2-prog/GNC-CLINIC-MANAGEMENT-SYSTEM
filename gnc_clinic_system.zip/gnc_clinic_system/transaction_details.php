<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transaction Details | GNCI</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<?php include('sidebar.php'); ?>

<div id="content">

    <header class="top-navbar">
        <div style="width:50px;"></div>
        <div class="header-title">GNCI CLINIC MANAGEMENT SYSTEM</div>
        <div class="header-right">
            <i class="fa-regular fa-envelope"></i>
            <i class="fa-regular fa-bell"></i>
            <div class="profile-circle">
                <img src="profile.png" alt="Profile">
            </div>
        </div>
    </header>

    <main class="main-container">

        <div class="form-header">
            <a href="history_transaction.php" style="color: white; text-decoration: none; margin-right: 10px;">&larr;</a> Transaction Details
        </div>

        <div class="form-body" style="background: transparent; box-shadow: none; padding: 0;">
            <div class="details-grid">
                
                <table class="details-table">
                    <thead>
                        <tr>
                            <th>Student Information</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Name: Santos, Pauline D.</td>
                        </tr>
                        <tr>
                            <td>Age: 21</td>
                        </tr>
                        <tr>
                            <td>Gender: Female</td>
                        </tr>
                        <tr>
                            <td>Phone Number: 09123456789</td>
                        </tr>
                        <tr>
                            <td>Address: Dinalupihan, Bataan</td>
                        </tr>
                        <tr>
                            <td>Student Type: College</td>
                        </tr>
                        <tr>
                            <td>Student ID: 20202022</td>
                        </tr>
                        <tr>
                            <td>Course: BSIT</td>
                        </tr>
                        <tr>
                            <td>Year & Section: 3rd year-3B</td>
                        </tr>
                    </tbody>
                </table>

                <table class="details-table">
                    <thead>
                        <tr>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Concern: Medicine</td>
                        </tr>
                        <tr>
                            <td>Details: Headache</td>
                        </tr>
                        <tr>
                            <td>Medicine: Paracetamol</td>
                        </tr>
                    </tbody>
                </table>

            </div>
        </div>

    </main>
</div>

</body>
</html>