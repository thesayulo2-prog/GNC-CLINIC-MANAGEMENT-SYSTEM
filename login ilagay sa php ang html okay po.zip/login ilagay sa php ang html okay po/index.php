<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Portal - Integrated System</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        /* --- COMBINED STYLES --- */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { height: 100vh; overflow: hidden; }
        
        /* View Management */
        .view { display: none; width: 100%; height: 100vh; }
        .view.active { display: flex; }

        /* Shared Layout */
        .left { width: 50%; background: #fff; display: flex; justify-content: center; align-items: center; position: relative; }
        .right { 
            width: 50%; 
            height: 100%; 
            background-image: url("images/nurse-concept-illustration_114360-15668.avif");
            background-position: center; 
            background-size: cover; 
            background-repeat: no-repeat;
            background-color: #f4f4f4; 
        }

        /* --- LANDING VIEW --- */
        #landingView .left-content { display: flex; flex-direction: column; align-items: center; gap: 20px; }
        #landingView .logo { width: 200px; transform: translateY(-70px); }
        #landingView .btn {
            width: 390px; padding: 10px; text-align: center; text-decoration: none;  
            background: transparent; color: #264d3b; border: 2px solid #264d3b;
            border-radius: 12px; font-size: 30px; font-weight: 600; cursor: pointer; transition: 0.3s;
        }
        #landingView .btn:hover { background: #264d3b; color: #fff; transform: scale(1.05); }

        /* --- FORM STYLES --- */
        .form-container { width: 100%; max-width: 350px; }
        h1 { font-size: 40px; margin-bottom: 20px; text-align: center; }
        .input-field { width: 100%; padding: 14px; border-radius: 12px; border: 1px solid #ccc; margin-bottom: 5px; font-size: 14px; outline: none; }
        .input-group { position: relative; margin-bottom: 15px; }
        .input-group i { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #777; font-size: 20px; }
        .input-group .input-field { padding-left: 40px; margin-bottom: 0; }
        
        .btn-submit { width: 100%; padding: 14px; background: #2f6f4e; color: #fff; border: none; border-radius: 12px; font-size: 16px; font-weight: 600; cursor: pointer; margin-top: 10px; transition: 0.3s; }
        .btn-submit:hover { background: #24563d; }
        .btn-submit:disabled { background: #ccc; cursor: not-allowed; }

        /* Custom Dropdown */
        .custom-select { width: 100%; position: relative; margin-bottom: 15px; }
        .select-box { padding: 14px; border-radius: 12px; border: 1px solid #ccc; cursor: pointer; background: #fff; user-select: none; }
        .select-box::after { content: "▼"; float: right; font-size: 12px; color: #777; }
        .options-container { position: absolute; width: 100%; background: #fff; border-radius: 12px; border: 1px solid #ccc; margin-top: 5px; display: none; z-index: 10; padding: 5px; }
        .option { padding: 12px; cursor: pointer; border-radius: 10px; }
        .option:hover { background: #2f6f4e; color: #fff; }

        .error-text { color: red; font-size: 13px; margin-bottom: 10px; display: block; height: 15px; }
        .footer-text { margin-top: 15px; font-size: 14px; text-align: center; }
        .strength-text { font-size: 12px; margin-bottom: 10px; display: block; }
    </style>
</head>
<body>

    <div id="landingView" class="view active">
        <div class="left">
            <div class="left-content">
                <img src="images/download.png" class="logo" alt="logo">
                <a href="#" class="btn" onclick="showView('loginView')">Login</a>
                <a href="#" class="btn" onclick="showView('registerView')">Register</a>
            </div>
        </div>
        <div class="right"></div>
    </div>

    <div id="loginView" class="view">
        <div class="left">
            <div class="form-container">
                <div style="text-align: center; margin-bottom: 20px;">
                    <a href="#" onclick="showView('landingView')">
                        <img src="images/download.png" style="width: 100px;" alt="logo">
                    </a>
                </div>
                <h1>Login</h1>
                <form id="loginForm">
                    <div class="custom-select" id="loginRoleSelect">
                        <div class="select-box">Select Role</div>
                        <div class="options-container">
                            <div class="option" data-value="ADMIN">ADMIN</div>
                            <div class="option" data-value="USER">USER</div>
                        </div>
                    </div>
                    <input type="hidden" id="loginRole">
                    
                    <div class="input-group">
                        <i class="fa fa-envelope"></i>
                        <input type="text" id="loginEmail" placeholder="Email Address" class="input-field">
                    </div>
                    <div class="input-group">
                        <i class="fa fa-key"></i>
                        <input type="password" id="loginPassword" placeholder="Password" class="input-field">
                    </div>
                    <small id="loginError" class="error-text"></small>
                    <button type="submit" id="loginBtn" class="btn-submit" disabled>Login</button>
                    
                    <p class="footer-text"><a href="#" onclick="showView('forgotView')" style="color: #2f6f4e; text-decoration: none;">Forgot password?</a></p>
                    <p class="footer-text">Don’t have an account? <a href="#" onclick="showView('registerView')" style="color: #2f6f4e; font-weight: 600; text-decoration: none;">Register</a></p>
                </form>
            </div>
        </div>
        <div class="right"></div>
    </div>

    <div id="registerView" class="view">
        <div class="left">
            <div class="form-container">
                <div style="text-align: center; margin-bottom: 20px;">
                    <a href="#" onclick="showView('landingView')">
                        <img src="images/download.png" style="width: 100px;" alt="logo">
                    </a>
                </div>
                <h1>Register</h1>
                <form id="registerForm">
                    <div class="custom-select" id="regRoleSelect">
                        <div class="select-box">Select Role</div>
                        <div class="options-container">
                            <div class="option" data-value="ADMIN">ADMIN</div>
                            <div class="option" data-value="USER">USER</div>
                        </div>
                    </div>
                    <input type="hidden" id="regRole">

                    <input type="text" id="regName" placeholder="Full Name" class="input-field">
                    <input type="email" id="regEmail" placeholder="Email" class="input-field">
                    <input type="password" id="regPass" placeholder="Password" class="input-field">
                    <input type="password" id="regConfirm" placeholder="Confirm Password" class="input-field">
                    <small id="regStrengthText" class="strength-text"></small>
                    
                    <button type="submit" id="registerBtn" class="btn-submit" disabled>Register</button>
                    
                    <p class="footer-text">Already have an account? <a href="#" onclick="showView('loginView')" style="color: #2f6f4e; font-weight: 600; text-decoration: none;">Login</a></p>
                </form>
            </div>
        </div>
        <div class="right"></div>
    </div>

    <div id="forgotView" class="view">
        <div class="left">
            <div class="form-container">
                <h1>Reset</h1>
                <form id="forgotForm">
                    <div class="custom-select" id="forgotRoleSelect">
                        <div class="select-box">Select Role</div>
                        <div class="options-container">
                            <div class="option" data-value="ADMIN">ADMIN</div>
                            <div class="option" data-value="USER">USER</div>
                        </div>
                    </div>
                    <input type="hidden" id="forgotRole">
                    <input type="email" id="forgotEmail" placeholder="Email" class="input-field">
                    <input type="password" id="newPassword" placeholder="New Password" class="input-field">
                    <small id="strengthText" class="strength-text"></small>
                    <input type="password" id="confirmPassword" placeholder="Confirm Password" class="input-field">
                    <button type="submit" id="resetBtn" class="btn-submit" disabled>Reset Password</button>
                    <p class="footer-text"><a href="#" onclick="showView('loginView')" style="color: #2f6f4e; text-decoration: none;">Back to Login</a></p>
                </form>
            </div>
        </div>
        <div class="right"></div>
    </div>

    <div id="dashboardView" class="view">
        <div style="padding: 50px; text-align: center; width: 100%;">
            <h1 id="welcomeText">Dashboard</h1>
            <button class="btn-submit" style="width:200px" id="logoutBtn">Logout</button>
        </div>
    </div>

    <script>
        // --- NAVIGATION ---
        function showView(viewId) {
            document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
            const target = document.getElementById(viewId);
            if(target) target.classList.add('active');
        }

        // --- DATABASE ---
        if (!localStorage.getItem("users")) {
            localStorage.setItem("users", JSON.stringify([
                { email: "admin@test.com", password: "Password123!", role: "ADMIN", name: "System Admin" },
                { email: "user@test.com", password: "Password123!", role: "USER", name: "Test User" }
            ]));
        }

        // --- DROPDOWN COMPONENT ---
        function initDropdown(containerId, hiddenInputId, callback) {
            const container = document.getElementById(containerId);
            const box = container.querySelector('.select-box');
            const options = container.querySelector('.options-container');
            const hiddenInput = document.getElementById(hiddenInputId);

            box.onclick = () => options.style.display = options.style.display === 'block' ? 'none' : 'block';

            container.querySelectorAll('.option').forEach(opt => {
                opt.onclick = () => {
                    box.textContent = opt.textContent;
                    hiddenInput.value = opt.dataset.value;
                    options.style.display = 'none';
                    if(callback) callback();
                };
            });

            document.addEventListener('click', (e) => { if (!container.contains(e.target)) options.style.display = 'none'; });
        }

        // --- LOGIN LOGIC ---
        const loginBtn = document.getElementById("loginBtn");
        function validateLogin() {
            const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
            loginBtn.disabled = !(document.getElementById("loginRole").value && document.getElementById("loginEmail").value.match(emailPattern) && document.getElementById("loginPassword").value.length >= 8);
        }
        initDropdown('loginRoleSelect', 'loginRole', validateLogin);
        ['loginEmail', 'loginPassword'].forEach(id => document.getElementById(id).oninput = validateLogin);

        document.getElementById("loginForm").onsubmit = (e) => {
            e.preventDefault();
            const users = JSON.parse(localStorage.getItem("users"));
            const found = users.find(u => u.email === document.getElementById("loginEmail").value.trim().toLowerCase() && u.password === document.getElementById("loginPassword").value && u.role === document.getElementById("loginRole").value);
            if (found) {
                document.getElementById("welcomeText").innerText = "Welcome, " + found.role;
                showView('dashboardView');
            } else {
                document.getElementById("loginError").innerText = "Invalid credentials";
            }
        };

        // --- REGISTER LOGIC ---
        const registerBtn = document.getElementById("registerBtn");
        function validateReg() {
            const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
            const pass = document.getElementById("regPass").value;
            const confirm = document.getElementById("regConfirm").value;
            registerBtn.disabled = !(document.getElementById("regRole").value && document.getElementById("regName").value.trim() && document.getElementById("regEmail").value.match(emailPattern) && pass.length >= 8 && pass === confirm);
        }
        initDropdown('regRoleSelect', 'regRole', validateReg);
        ['regName', 'regEmail', 'regPass', 'regConfirm'].forEach(id => document.getElementById(id).oninput = validateReg);

        document.getElementById("registerForm").onsubmit = (e) => {
            e.preventDefault();
            let users = JSON.parse(localStorage.getItem("users"));
            const email = document.getElementById("regEmail").value.trim().toLowerCase();
            if(users.some(u => u.email === email)) return alert("Email already exists");
            
            users.push({
                role: document.getElementById("regRole").value,
                name: document.getElementById("regName").value,
                email: email,
                password: document.getElementById("regPass").value
            });
            localStorage.setItem("users", JSON.stringify(users));
            alert("Registered successfully!");
            showView('loginView');
        };

        // --- RESET LOGIC ---
        const resetBtn = document.getElementById("resetBtn");
        function validateReset() {
            const pass = document.getElementById("newPassword").value;
            resetBtn.disabled = !(document.getElementById("forgotRole").value && document.getElementById("forgotEmail").value && pass.length >= 8 && pass === document.getElementById("confirmPassword").value);
        }
        initDropdown('forgotRoleSelect', 'forgotRole', validateReset);
        ['forgotEmail', 'newPassword', 'confirmPassword'].forEach(id => document.getElementById(id).oninput = validateReset);

        document.getElementById("forgotForm").onsubmit = (e) => {
            e.preventDefault();
            let users = JSON.parse(localStorage.getItem("users"));
            const idx = users.findIndex(u => u.email === document.getElementById("forgotEmail").value.trim().toLowerCase() && u.role === document.getElementById("forgotRole").value);
            if(idx !== -1) {
                users[idx].password = document.getElementById("newPassword").value;
                localStorage.setItem("users", JSON.stringify(users));
                alert("Updated!");
                showView('loginView');
            } else alert("Account not found");
        };

        // --- LOGOUT ---
        document.getElementById("logoutBtn").onclick = () => showView('loginView');
    </script>
</body>
</html>